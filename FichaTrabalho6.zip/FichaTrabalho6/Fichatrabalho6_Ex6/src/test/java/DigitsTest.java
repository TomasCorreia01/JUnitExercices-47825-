import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class DigitsTest {
    private Digits digits;

    @BeforeEach
    public void setUp() {
        digits = new Digits();
    }

    @Test
    public void testCalculateAverageDigitsPositiveNumber() {
        double average = Digits.calculateAverageDigits(12345);
        assertEquals(3.0, average, 0.001);
    }

    @Test
    public void testCalculateAverageDigitsSingleDigitNumber() {
        double average = Digits.calculateAverageDigits(7);
        assertEquals(7.0, average, 0.001);
    }

    public Digits getDigits() {
        return digits;
    }

    public void setDigits(Digits digits) {
        this.digits = digits;
    }
}
