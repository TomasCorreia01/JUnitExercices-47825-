public class Digits {
    public static double calculateAverageDigits(int number) {

        int absNumber = Math.abs(number);
        int sumDigits = 0;
        int digitCount = 0;

        while (absNumber > 0) {
            int digit = absNumber % 10;
            sumDigits += digit;
            digitCount++;
            absNumber /= 10;
        }

        return (double) sumDigits / digitCount;
    }
}
