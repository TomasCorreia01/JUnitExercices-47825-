import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class RectangleTest {

    @Test
    public void testAreaCase1() {
        Rectangle Rectangle = new Rectangle();
        int result = Rectangle.area(3, 5);
        assertEquals(15, result, "Area of rectangle with base of 3 and height of 5 should be 15");
    }

    @Test
    public void testPerimeterCase1() {
        Rectangle Rectangle = new Rectangle();
        int result = Rectangle.perimeter(3, 5);
        assertEquals(16, result, "Perimeter of rectangle with base of 3 and height of 5 should be 16");
    }

    @Test
    public void testAreaCase2() {
        Rectangle Rectangle = new Rectangle();
        int result = Rectangle.area(5, 8);
        assertEquals(40, result, "Area of rectangle with base of 5 and height of 8 should be 40");
    }

    @Test
    public void testPerimeterCase2() {
        Rectangle Rectangle = new Rectangle();
        int result = Rectangle.perimeter(5, 8);
        assertEquals(26, result, "Perimeter of rectangle with base of 5 and height of 8 should be 26");
    }

    @Test
    public void testAreaCase3() {
        Rectangle Rectangle = new Rectangle();
        int result = Rectangle.area(2, 4);
        assertEquals(8, result, "Area of rectangle with base of 2 and height of 4 should be 8");
    }

    @Test
    public void testPerimeterCase3() {
        Rectangle Rectangle = new Rectangle();
        int result = Rectangle.perimeter(2, 4);
        assertEquals(12, result, "Perimeter of the rectangle with base of 2 and height of 4 should be 12");
    }

    @Test
    public void testIsTriangleTrue() {
        Rectangle Rectangle = new Rectangle();
        boolean result = Rectangle.isTriangle(3, 4, 5);
        assertTrue(result, "its possible to form a triangle with 3, 4 e 5");
    }

    @Test
    public void testIsTriangleFalse() {
        Rectangle Rectangle = new Rectangle();
        boolean result = Rectangle.isTriangle(1, 2, 3);
        assertFalse(result, "Its not possible to form a triangle with 1, 2 and 3");
    }
}
