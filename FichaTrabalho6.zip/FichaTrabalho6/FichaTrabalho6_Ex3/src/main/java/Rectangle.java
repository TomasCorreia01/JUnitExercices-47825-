public class Rectangle {

    // b)
    public int area(int base, int height) {
        return base * height;
    }

    // b)
    public int perimeter(int base, int height) {
        return 2 * (base + height);
    }

    // d)
    public boolean isTriangle(int a, int b, int c) {
        return (a + b > c) && (a + c > b) && (b + c > a);
    }
}
